   
   <footer class="sticky-footer" style="width:100%; position:relative; top:9em;">
        <div class="container my-auto">
            <div class="copyright text-center my-auto" style="font-size:13px;">
            <span style="color: #fff">Sistema Academico © 2019</span>
            </div>
        </div>
    </footer>    

        <!-- /.content-wrapper -->

    <!-- /#wrapper -->
    
    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../vendor/chart.js/Chart.min.js"></script>


</body>

</html>